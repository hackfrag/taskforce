$(document).ready(function() {
	Todo.init();
}); 